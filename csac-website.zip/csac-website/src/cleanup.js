const fs = require('fs');
const path = require('path');

const filePath = path.join(__dirname, 'index.html');
let html = fs.readFileSync(filePath, 'utf8');

// 1. committee-grid-new
html = html.replace(/<div class="committee-grid-new">[\s\S]*?<\/section>/, '<div class="committee-grid-new"></div>\n  </section>');

// 2. members-grid
html = html.replace(/<div class="members-grid" id="members-grid">[\s\S]*?(<div class="members-no-results" id="members-no-results">[\s\S]*?<\/div>)[\s\S]*?<\/section>/, '<div class="members-grid" id="members-grid">\n      $1\n    </div>\n  </section>');

// 3. week-timeline
html = html.replace(/<div class="week-timeline">[\s\S]*?<\/section>/, '<div class="week-timeline"></div>\n  </section>');

// 4. reports-grid
html = html.replace(/<div class="reports-grid">[\s\S]*?<\/section>/, '<div class="reports-grid"></div>\n  </section>');

// 5. masonry-grid
html = html.replace(/<div class="masonry-grid reveal">[\s\S]*?<\/section>/, '<div class="masonry-grid reveal"></div>\n  </section>');

// 6. counters-grid
html = html.replace(/<div class="counters-grid">[\s\S]*?<\/section>/, '<div class="counters-grid"></div>\n  </section>');

// 7. testimonial-track
html = html.replace(/<div class="testimonial-track">[\s\S]*?<\/div>\s*<div class="slider-controls">/, '<div class="testimonial-track"></div>\n\n      <div class="slider-controls">');

fs.writeFileSync(filePath, html);
console.log('HTML cleanup done.');
